export class Entry {
    name: string;
    value: string;

    constructor(_n: string, _v: string) {
        this.name = _n;
        this.value = _v;
    }
}



export class LocResult {
    entries: Entry[];
    filteredCount: number;
    filtered: Entry[];

    constructor (arr: object, _key: string[]) {
        let _name: string[];
        let _value: string[];

        _name = Object.keys(arr);
        // _value = Object.values(arr);     // Doesn't work for IE
        _value = Object.keys(arr).map(itm => arr[itm]);
        this.entries = [];
        this.filtered = [];

        for (let i = 0; i < _name.length; i++) {
            this.entries.push(new Entry(_name[i], _value[i]));
            // Check if the key name is in Key array. If not, filter it out.
            if (this.ifExists(_name[i], _key) === false) {
                console.log('Name: ', _name[i], ', Value: ', _value[i]);
            } else {
                this.filtered.push(new Entry(_name[i], _value[i]));
            }
        }
    }

    ifExists(name: string, key: string[]): boolean {
        for (let i = 0; i < key.length; i++) {
            if (name === key[i]) {
                return true;
            }
        }
        return false;
    }
}

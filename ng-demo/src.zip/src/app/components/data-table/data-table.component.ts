import { Component, OnInit, Input } from '@angular/core';
import { HttpClientModule, HttpErrorResponse, HttpClient } from '@angular/common/http';
import { LocResult } from '../../models/locResult';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css']
})
export class DataTableComponent implements OnInit {

  @Input() dtLabel: string;         // Label of Data Table

  @Input() dtDataSource: string;    // REST URL to get data

  @Input() dtHeaderData: any;       // JSON for Table fields and header labels to be displayed

  @Input() dtEnableDelete: boolean; // To have Delete Button or not

  headerLabel: string[];
  headerType: string[];

  locResults: LocResult[];
  results: any[];

  selectedRow: number;

  constructor(private http: HttpClient) { }

  ngOnInit() {
    console.log('dtHeaderData: ' + this.dtHeaderData);
    this.http.get(this.dtHeaderData).subscribe(
      data => {
        this.headerType = Object.keys(data);
        // this.headerLabel = Object.values(data);
        this.headerLabel =  Object.keys(data).map(itm => data[itm]);
        console.log('Type: ', this.headerType);
        console.log('Labels: ', this.headerLabel);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );

    console.log('dtDataSource: ' + this.dtDataSource);
    this.locResults = [];
    this.http.get(this.dtDataSource).subscribe(
      data => {
        this.results = data as any[];
        for (let i = 0; i < this.results.length; i++) {
          this.locResults[i] = new LocResult(this.results[i], this.headerType);
          console.log(i + 1, '> ', this.results[i]);
        }
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );

  }

}
